//-----------------------------------------------------------------------------------------
//Dependencies
//Modules
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import {FlashMessagesModule} from 'angular2-flash-messages';
import { Ng2OrderModule } from 'ng2-order-pipe';
import {NgxPaginationModule} from 'ngx-pagination';

//Components
import { AppComponent } from './app.component';
import { AddBookComponent } from './components/add-book/add-book.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { HomeComponent } from './components/home/home.component';
import { SearchComponent } from './components/search/search.component';
import { CreateUserComponent } from './components/create-user/create-user.component';
import { InfoComponent } from './components/info/info.component';
import { AdvancedsearchComponent } from './components/advancedsearch/advancedsearch.component';
import { LoginComponent } from './components/login/login.component';
import { ProfileComponent } from './components/profile/profile.component';
import { RegisterComponent } from './components/register/register.component';
import { ForgotComponent } from './components/forgot/forgot.component';
import{ UserComponent} from './components/user/user.component';
import { UsersComponent } from './components/users/users.component';


//Services
import {AddBookService} from './services/addbook.service';
import { BarcodeComponent } from './components/barcode/barcode.component';
import { ReturnComponent } from './components/return/return.component';




//-----------------------------------------------------------------------------------------

//Page routes
const ROUTES: Routes = [
  { path: '', component: HomeComponent},
  { path: 'addbook', component: AddBookComponent},
  { path: 'search', component: SearchComponent},
  { path: 'info', component: InfoComponent},
  { path: 'advancedsearch', component: AdvancedsearchComponent},
  { path: 'createuser', component: CreateUserComponent},
  { path: 'login', component: LoginComponent},
  { path: 'profile', component: ProfileComponent},
  { path: 'forgot', component: ForgotComponent},
  { path: 'register', component: RegisterComponent},
  { path: 'users', component: UsersComponent},
  { path: 'users/:error', component: UsersComponent},
  { path: 'user/:userNumber', component: UserComponent},
  { path: 'barcode/:barcode', component: BarcodeComponent},
  { path: 'returnbooks', component: ReturnComponent}
  
];

//-----------------------------------------------------------------------------------------

@NgModule({
  declarations: [
    AppComponent,
    AddBookComponent,
    NavbarComponent,
    HomeComponent,
    SearchComponent,
    InfoComponent,
    AdvancedsearchComponent,
    CreateUserComponent,
    LoginComponent,
    ProfileComponent,
    RegisterComponent,
    ForgotComponent,
    UsersComponent,
    UserComponent,
    BarcodeComponent,
    ReturnComponent 
  ],
  imports: [
    BrowserModule,
    HttpModule,
    RouterModule.forRoot(ROUTES),
    FormsModule,
    FlashMessagesModule,
    Ng2OrderModule,
    NgxPaginationModule
  ],
  providers: [AddBookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
