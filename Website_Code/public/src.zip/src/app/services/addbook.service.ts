import { Injectable } from '@angular/core';
import { Book } from '../models/book.model'; 
import { BookValidation } from '../models/validation.model'; 

@Injectable()
export class AddBookService {

  constructor() { }

  checkAddBook(book:Book): BookValidation{
    
    var valid = new(BookValidation);
    //--Cover Art---------------------------
    if(book.coverArt){
      const filetypes = /jpeg|jpg|png|gif/;
      const mimetype = filetypes.test(book.coverArt.name);
      if(!mimetype){
        valid.coverArt = false;
      }
    }
    //--title----------------------  
    if(!book.title){
      valid.title = false;

    }else if(book.title.length<1){
      valid.title = false;
    }else{
      valid.title = true;
    }
    //--author--------------------------
        
      if((!book.authorFirstName) || (!book.authorLastName)){
        valid.author = false;
      }else if((book.authorFirstName.length<2)&&(book.authorLastName.length<2)){
        valid.author = false;
      }else{
        valid.author = true;
      }  

    //--isbn----------------------
    if(!book.isbn){
      valid.isbn = false;

    }else if(book.isbn < 1000000000000 || book.isbn > 9999999999999){
      valid.isbn = false;
    }else{
      valid.isbn = true;
    }
    
    //--publisher----------------------
    if(!book.publisher){
      valid.publisher = false;

    }else if(book.publisher.length<2){
      valid.publisher = false;
    }else{
      valid.publisher = true;
    }
    //--language----------------------
    if(!book.language){
      valid.language = false;

    }else if(book.language.length<2){
      valid.language = false;
    }else{
      valid.language = true;
    }
    //--year----------------------
    if(!book.year){
      valid.year = false;

    }else if(book.year < 1){
      valid.year = false;
    }else{
      valid.year = true;
    }
    //--copies----------------------
    if(!book.noCopies){
      valid.noCopies = false;

    }else if(book.noCopies < 1){
      valid.noCopies = false;
    }else{
      valid.noCopies = true;
    }

    if(
      valid.title == true &&
      valid.author == true &&
      valid.isbn == true &&
      valid.year == true &&
      valid.publisher == true &&
      valid.description == true &&
      valid.language == true &&
      valid.coverArt == true &&
      valid.noCopies ==true)
      {
        valid.book = true;
      }else{
        valid.book = false;
      }
    return valid;
  }


}
