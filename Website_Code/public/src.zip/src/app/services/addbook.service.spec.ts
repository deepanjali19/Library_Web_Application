import { TestBed, inject } from '@angular/core/testing';

import { AddbookService } from './addbook.service';

describe('AddbookService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddbookService]
    });
  });

  it('should be created', inject([AddbookService], (service: AddbookService) => {
    expect(service).toBeTruthy();
  }));
});
