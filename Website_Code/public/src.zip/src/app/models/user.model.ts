export class User {
    _id: string;
    userType: string;
    number: string;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    password: string;
    street: string;
    apt: string;
    city: string;
    postalCode: string;
    province: string;
    reserve;
    loan;
}