export class Book{
    
    
        id: string;
        title: string;
        isbn: number;
        year: number;
        publisher: string;
        description: string;
        language: string;
        noCopies: number = 1;
        authorFirstName: string;
        authorLastName: string;
        coverArt: File;
        copies;
        loan:[string];
        reserve:[string];
    }