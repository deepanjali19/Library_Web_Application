export class BookValidation{
    
    book: boolean;
    title: boolean;
    author: boolean;
    isbn: boolean;
    year: boolean;
    publisher: boolean;
    description: boolean;
    language: boolean;
    noCopies: boolean;
    coverArt: boolean;

    constructor(){
        this.title = true;
        this.isbn = true;
        this.year = true;
        this.publisher = true;
        this.description = true;
        this.language = true;
        this.noCopies = true;
        this.author = true;
        this.book = false;
        this.coverArt = true;

    }

}