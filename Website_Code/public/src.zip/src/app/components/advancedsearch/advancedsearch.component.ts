import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute} from '@angular/router';
import { query } from '@angular/core/src/animation/dsl';

@Component({
  selector: 'app-advancedsearch',
  templateUrl: './advancedsearch.component.html',
  styleUrls: ['./advancedsearch.component.css']
})

export class AdvancedsearchComponent implements OnInit {

  options = ["ISBN","Author","Title","Year","Publisher"];
  andOptions = ["ISBN","Author","Title","Year","Publisher"];
  query = [];
  message;
  and = "and";
  constructor(public http: Http, private router: Router, private activatedRoute: ActivatedRoute) {}

  ngOnInit() {  
    this.query.push({condition: "and", choice: "ISBN", query: ""});
  }

  advancedSearch(){
    var good = true;

    
    for(var i = 0; i<this.query.length;i++){
      this.query[i].message = "";
      if(i==0&&(this.query.length == 0 || this.query[0].query.trim()=="")){
        this.query[0].message = "No query parameter given";
        good = false;
      }
      if(this.query[i].query.trim()==""&& i!=0){
        this.query.splice(i,1);
        i--;
      }else{
        if(!this.query[i].choice){
          this.query[i].message = "A condition is needed to perform this search";
          good = false;
        }
      }
    }
    if(good){
      this.router.navigate(['/search'], { queryParams: { searchType: "advanced", query: JSON.stringify(this.query)}, skipLocationChange: false });
    }
  }

  addLine(){
    this.query.push({condition: "and", choice: "", query: ""});
  }

  reset(){
    this.query = [];
    this.query.push({condition: "and", choice: "ISBN", query: ""});
  }
}
