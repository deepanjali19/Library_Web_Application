import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, Response } from '@angular/http';
import { FlashMessagesService } from 'angular2-flash-messages';
import { User } from '../../models/user.model';
import 'rxjs/add/operator/map';
import { DomSanitizer } from '@angular/platform-browser';
import * as moment from 'moment'

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  message: string;
  book: string;
  books = [];
  loanedBooks = [];
  loanBook = {
    bookId: String,
    bookCode: String
  };
  loans = [];
  reservations = [];
  user: User;
  user2: User;
  userNumber: any;
  nav = {
    checkout: true,
    profile: false,
    modify: false,
    reservations: false,
    loans: false
  };

  valid = {
    firstName: true,
    lastName: true,
    email: true,
    phone: true,
    address: true,
    city: true,
    postalCode: true,
    province: true,
    user: true
  };

  //-----------------------------------------------------------------------------------------------------------------
  constructor(private http: Http, private activatedRoute: ActivatedRoute, private router: Router, private flashMessage: FlashMessagesService, private sanitizer: DomSanitizer) {
    this.user = new User();
    this.userNumber = activatedRoute.snapshot.params['userNumber'];
    this.http.get('http://localhost:3000/users', { search: { 'userNumber': this.userNumber } })
      .map(res => res.json()).subscribe((data) => {
        if (!data.found) {
          this.router.navigate(['/users', "error"]);
        } else {
          this.user = Object.assign({}, data.user);
          this.user2 = Object.assign({}, data.user);
          this.reservations = data.reservations;
          console.log(data);
        }
      });
  }
  //-----------------------------------------------------------------------------------------------------------------
  getLoans() {
    this.http.get('http://localhost:3000/getloans', { search: { 'userNumber': this.userNumber } })
      .map(res => res.json()).subscribe((data) => {
        if (!data.found) {
          this.loans = [];
        } else {

          this.loans = data.loans;
          for (var i = 0; i < this.loans.length; i++) {

            var tfn = this.loans[i].book.coverArt.split("/");
            var fileNm = tfn[tfn.length - 1];
            this.loans[i].book.coverArt = "http://localhost:3000/pics?image=" + fileNm;
          }
          console.log(this.loans);
        }


      });
  }

  renew(id: string) {
    console.log("id: " + id);
    this.http.put('http://localhost:3000/renew', { loanId: id }).map(res => res.json()).subscribe(data => {
      if (data.success) {
        this.getLoans();
        window.scrollTo(0, 0);
        this.flashMessage.show(data.message, { cssClass: 'alert-success', timeout: 5000 });
      } else {
        window.scrollTo(0, 0);
        this.flashMessage.show(data.message, { cssClass: 'alert-danger', timeout: 5000 });
      }
    });
  }

  getReserve() {
    this.http.get('http://localhost:3000/getreserves', { search: { 'userNumber': this.userNumber } })
      .map(res => res.json()).subscribe((data) => {
        if (!data.found) {
          this.reservations = [];
        } else {

          this.reservations = data.reserves;
          for (var i = 0; i < this.reservations.length; i++) {

            var tfn = this.reservations[i].book.coverArt.split("/");
            var fileNm = tfn[tfn.length - 1];
            this.reservations[i].book.coverArt = "http://localhost:3000/pics?image=" + fileNm;
          }
          console.log(this.reservations);
        }


      });
  }

  addBook(book) {
    let inBooks = false;

    if (Number.isInteger(parseInt(book))) {
        this.http.get('http://localhost:3000/checkout', { search: { 'bookNumber': book } })
          .map(res => res.json())
          .subscribe((data) => {
            if (!data.found) {
              //console.log(data.found);
              this.message = "Can Not Find Book!";
            } else {
                this.message = "";
                // this.books.push(data.book);
                // this.books[this.books.length - 1].copies = book;
                // this.book = "";
                var bc ={ bookId: data.book._id, bookCode: book };
                
                this.checkout(bc);
                //console.log(data.book);
            }
          });
  
      // this.books.push(parseInt(book));
      // console.log(this.book);
      // this.book = "";
      // this.message = "";

    } else {
      this.message = "Invalid Book Code Format!";
    }
  }
  //-----------------------------------------------------------------------------------------------------------------
  checkout(book) {
    //console.log("in checkout");
    //console.log(this.userNumber);
    //console.log(this.books);
    //console.log(this.loanedBooks);
    this.http.put('http://localhost:3000/loan', { loanedBooks: book, userId: this.userNumber }).map(res => res.json()).subscribe(data => {
      console.log(data);
      if (data.success) {
        
        window.scrollTo(0, 0);
        this.book = "";
        let saying = data.book.title+" Successfully checked out! Due back "+moment(data.loan.dueDate).format('dddd, MMMM Do YYYY');
        this.flashMessage.show(saying, { cssClass: 'alert-success', timeout: 9000 });
      } else {
        window.scrollTo(0, 0);
        this.flashMessage.show(data.message, { cssClass: 'alert-danger', timeout: 5000 });
      }
    });

  }
  //-----------------------------------------------------------------------------------------------------------------
  removeBook(index: number) {
    this.books.splice(index, 1);
  }
  //-----------------------------------------------------------------------------------------------------------------
  editUser() {
    this.validate(this.user2.firstName,
      this.user2.lastName,
      this.user2.email,
      this.user2.phoneNumber,
      this.user2.street,
      this.user2.city,
      this.user2.province,
      this.user2.postalCode,
      this.valid
    );


    if (this.valid.user) {
      this.http.put('http://localhost:3000/edituser', this.user2).map(res => res.json()).subscribe(res => {
        if (res.success == true) {
          this.user = Object.assign({}, this.user2);
          this.changeNav('profile');
          window.scrollTo(0, 0);
          this.flashMessage.show(res.message, { cssClass: 'alert-success', timeout: 5000 });
        } else if (res.success == false) {
          this.flashMessage.show(res.message, { cssClass: 'alert-danger', timeout: 5000 });
          window.scrollTo(0, 0);
        }
      });
    }
  }


  //-----------------------------------------------------------------------------------------------------------------
  cancelButton() {
    this.user2 = Object.assign({}, this.user);
    window.scrollTo(0, 0);
    this.changeNav('profile');
  }

  //-----------------------------------------------------------------------------------------------------------------
  changeNav(name: string) {
    let temp = document.getElementsByClassName('active');
    for (var i = 0; i < temp.length; i++) {
      temp[i].classList.remove("active");
    }
    if (name === "checkout") {
      this.nav.checkout = true;
      this.nav.loans = false;
      this.nav.modify = false;
      this.nav.profile = false;
      this.nav.reservations = false;
      document.getElementById(name).className += " active";
    } else if (name === "profile") {
      this.nav.checkout = false;
      this.nav.loans = false;
      this.nav.modify = false;
      this.nav.profile = true;
      this.nav.reservations = false;
      document.getElementById(name).className += " active";
    } else if (name === "modify") {
      this.nav.checkout = false;
      this.nav.loans = false;
      this.nav.modify = true;
      this.nav.profile = false;
      this.nav.reservations = false;
      document.getElementById(name).className += " active";
    } else if (name === "reservations") {
      this.getReserve();
      this.nav.checkout = false;
      this.nav.loans = false;
      this.nav.modify = false;
      this.nav.profile = false;
      this.nav.reservations = true;
      document.getElementById(name).className += " active";
    } else if (name === "loans") {
      this.getLoans();
      this.nav.checkout = false;
      this.nav.loans = true;
      this.nav.modify = false;
      this.nav.profile = false;
      this.nav.reservations = false;
      document.getElementById(name).className += " active";
    }
  }

  //-----------------------------------------------------------------------------------------------------------------
  validate(firstName, lastName, email, phone, address, city, province, postalCode, valid) {
    valid.firstName = true;
    valid.lastName = true;
    valid.phone = true;
    valid.email = true;
    valid.user = true;
    valid.address = true;
    valid.city = true;
    valid.postalCode = true;
    valid.province = true;

    //names
    if (!firstName) {
      valid.firstName = false;
    } else if (firstName.trim().length == 0) {
      valid.firstName = false;
    }

    if (!lastName) {
      valid.lastName = false;
    } else if (lastName.trim().length == 0) {
      valid.lastName = false;
    }
    //email
    if (!email) {
      valid.email = false;
    } else if (email.split('@').length != 2) {
      valid.email = false;
    } else {
      var temp = email.split('@');
      var temp2 = temp[1].split('.');

      if (temp2.length < 2) {
        valid.email = false;
      } else if (temp2[0].length < 1 || temp2[1].length < 1) {
        valid.email = false;
      }
    }

    //phone
    if (!phone) {
      valid.phone = false;
    } else if (phone.length < 10) {
      valid.phone = false;
    } else {
      var temp3 = phone.split('-');

      if (temp3.length != 3) {
        valid.phone = false;
      }

      if ((((temp3[0].trim().length) != 3))) {

        valid.phone = false;

      }
      if (((temp3[1].trim().length) != 3)) {

        valid.phone = false;

      }
      if (((temp3[2].trim().length) != 4)) {

        valid.phone = false;

      }
    }


    //address
    if (!address) {
      valid.address = false;
    } else if (address.trim().length == 0) {
      valid.address = false;
    }
    //city
    if (!city) {
      valid.city = false;
    } else if (city.trim().length == 0) {
      valid.city = false;
    }
    //province
    if (!province) {
      valid.province = false;
    } else if (province.trim().length == 0) {
      valid.province = false;
    }
    //postal code
    var regex = /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/;
    var match = regex.exec(postalCode);
    if (!postalCode) {
      valid.postalCode = false;
    } else if (postalCode.trim().length == 0) {
      valid.postalCode = false;
    } else if (!match) {
      valid.postalCode = false;
    }
    //user
    if (valid.firstName &&
      valid.lastName &&
      valid.email &&
      valid.phone &&
      valid.address &&
      valid.city &&
      valid.postalCode &&
      valid.province
    ) {
      valid.user = true;
    } else {
      valid.user = false;
    }

    return valid;
  }

  findSpot(reserve) {
    //console.log(reserve);
    //console.log(reserve._id);
    //console.log(reserve.book.reserve);
    return (reserve.book.reserve.findIndex(el => el == reserve._id) + 1);
  }

  formatDate(rDate) {
    return moment(rDate).format("MMMM D, YYYY");
  }

  cancelReservation(r) {
    this.http.put('http://localhost:3000/cancelreserve', { reserveId: r, userId: this.user._id }).map(res => res.json()).subscribe(data => {
      if (data.success) {
        this.flashMessage.show('Reservation for this book cancelled!', { cssClass: 'alert-success', timeout: 5000 });
        this.getReserve();
      } else {
        this.flashMessage.show('Reservation not cancelled!', { cssClass: 'alert-danger', timeout: 5000 });
      }

      console.log(data.success);
    });
  }
}