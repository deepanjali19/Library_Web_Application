import { Component, ElementRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Router, ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  password: string;
  number: any;
  found: boolean;

  constructor(public http: Http, public el: ElementRef, private router: Router) { this.found = true; }

  login(){
    let myForm : HTMLFormElement =<HTMLFormElement> document.getElementById('myIForm');
    let formData = new FormData(myForm);
    
    if(!this.password){
      this.found = false;
    }else if(this.password=="_"){
      this.found = false;
    }else{
      this.http.post('http://localhost:3000/login',
      formData)
      .subscribe(res => {
        var answer = res.json();
        if(answer.success == true){
          this.found = true;
          //set session data----------------------------------------------------------------------------------------
          console.log(answer.user);
          sessionStorage.setItem('token', answer.token);
          sessionStorage.setItem('loggedIn', 'true');
          sessionStorage.setItem('id', answer.user.id);
          sessionStorage.setItem('user', answer.user.userType);
          sessionStorage.setItem('number', answer.user.number);
          sessionStorage.setItem('firstName', answer.user.firstName);
          sessionStorage.setItem('lastName', answer.user.lastName);
          this.router.navigate(['/profile']);
          //this.router.navigate(['/profile'], { queryParams: { number: answer.user.number}});          
        }else if(answer.success ==false){
          window.scrollTo(0, 0);
          this.found = false;        
        }       
      });
    }
  }
 
  toForget(){
    this.http.get('http://localhost:3000/forgot');
  }

}
