import { Component } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';
import { User } from '../../models/user.model';
import { DomSanitizer } from '@angular/platform-browser';
import 'rxjs/add/operator/map';
import * as moment from 'moment'


@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent {

  userId: string;
  email: string;
  phoneNumber: string;
  /*
  firstName: string;
  lastName: string;
  number: number;
  userType: string;
  street: string;
  apt: string;
  city: string;
  postalCode: string;
  province: string;
  */
  user: any;
  loanedBooks = [];
  loanBook = {
    bookId: String,
    bookCode: String
  };
  loans = [];
  reservations = [];
  edit: boolean;
  _phoneNumber: string;
  _email: string;
  valid = {
    email: true,
    phone: true,
    user: true
  };
  editPass: boolean;
  password: string;
  password2: string;
  validPass: boolean;
  nav = {
    profile: true,
    changePassword: false,
    reservations: false,
    loans: false
  };

  constructor(private http: Http, private router: Router, private activatedRoute: ActivatedRoute, private flashMessage: FlashMessagesService) {
    this.user = new User();
    this.edit = false;
    this.userId = this.sessionStorageItem('id');
    this.editPass = false;
    this.validPass = true;

    this.activatedRoute.queryParams.subscribe(params => {
      let header = new Headers();
      header.append('Authorization', 'Bearer ' + sessionStorage.getItem('token'));
      this.http.get('/profile', { headers: header, search: { number: sessionStorage.getItem('number') } })
        .map(res => res.json()).subscribe(data => {
          this._email = this.email;
          this._phoneNumber = this.phoneNumber;
          /*
          this.email = data.email;
          this.firstName = data.firstName;
          this.lastName = data.lastName;
          this.number = data.number;
          this.phoneNumber = data.phoneNumber;
          this.userType = data.userType;
          this._email = this.email;
          this._phoneNumber = this.phoneNumber;
          this.street = data.street;
          this.apt = data.apt;
          this.city = data.city;
          this.postalCode = data.postalCode;
          this.province = data.province;
          this.reservations = data.reserve;
          */
          this.changeNav('profile');
          this.user = data;
          console.log(data);
        });
    });
  }

  renew(id: string){
    console.log("id: " + id);
    this.http.put('http://localhost:3000/renew', { loanId: id}) .map(res => res.json()).subscribe(data => {
      if(data.success){
        this.getLoans();
        window.scrollTo(0, 0);
        this.flashMessage.show(data.message, { cssClass: 'alert-success', timeout: 5000 });
      } else {
        window.scrollTo(0, 0);
        this.flashMessage.show(data.message, { cssClass: 'alert-danger', timeout: 5000 });
      }
    });
  }


  cancelReservation(r) {
    this.http.put('http://localhost:3000/cancelreserve', { reserveId: r, userId: sessionStorage.getItem('id') }).map(res => res.json()).subscribe(data => {
    if(data.success){
      this.flashMessage.show('Reservation for this book cancelled!', { cssClass: 'alert-success', timeout: 5000 });
      this.getReserve();
    } else {
      this.flashMessage.show('Reservation not cancelled!', { cssClass: 'alert-danger', timeout: 5000 });
    }
  
    console.log(data.success);
    });
  }

  toggleEdit() {
    this._email = this.user.email;
    this._phoneNumber = this.user.phoneNumber;
    this.edit = !this.edit;
  }

  sessionStorageItem(id: string): string {
    return sessionStorage.getItem(id);
  }
  togglePass() {
    //this.editPass = !this.editPass;
    this.changeNav("profile");
    this.password="";
    this.password2="";
  }


  validate(email, phone, valid) {

    valid.phone = true;
    valid.email = true;
    valid.user = true;

    //email
    if (!email) {
      valid.email = false;
    } else if (email.split('@').length != 2) {
      valid.email = false;
    } else {
      var temp = email.split('@');
      var temp2 = temp[1].split('.');
      if (email.includes(" ")) {
        valid.email = false;
      }

      if (temp2.length < 2) {
        valid.email = false;
      } else if (temp2[0].length < 1 || temp2[1].length < 1) {
        valid.email = false;
      }
    }
    //phone
    if (!phone) {
      valid.phone = false;
    } else if (phone.length < 10) {
      valid.phone = false;
    }

    var temp3 = phone.split('-');

    if (temp3.length != 3) {
      valid.phone = false;
    }

    if ((((temp3[0].trim().length) != 3))) {

      valid.phone = false;

    }
    if (((temp3[1].trim().length) != 3)) {

      valid.phone = false;

    }
    if (((temp3[2].trim().length) != 4)) {

      valid.phone = false;

    }

    //user
    if (valid.email && valid.phone) {
      valid.user = true;
    } else {
      valid.user = false;
    }

    return valid;
  }

  // EDITING USER INFO & CHANGING PASSWORD 
  submit() {
    this.validate(this._email, this._phoneNumber, this.valid);
    if (this.valid.user) {
      // var headers = new Headers({
      //   'Content-Type': 'application/json'
      // });
      this.http.put('http://localhost:3000/profile',
        { editPass: false, number: this.user.number, email: this._email, phoneNumber: this._phoneNumber })
        .subscribe(res => {
          this.toggleEdit();
          var answer = res.json();
          this.user.email = answer.email;
          this.user.phoneNumber = answer.phoneNumber;
          this.flashMessage.show('Profile Was Successfully Updated!', { cssClass: 'alert-success', timeout: 5000 });

        });
    } else {
      window.scrollTo(0, 0);
    }
  }


  submitPass() {
    if (this.password && this.password2) {
      if (this.password.trim().length > 0) {
        if (this.password == this.password2) {
          this.http.put('http://localhost:3000/profile',
            { editPass: true, number: this.user.number, password: this.password })
            .subscribe(res => {
              this.validPass = true;
              this.togglePass();
              var answer = res.json();
              this.changeNav("profile");
              this.flashMessage.show('Password Was Successfully Updated!', { cssClass: 'alert-success', timeout: 5000 });
              this.password="";
              this.password2="";
            });
        } else {
          this.validPass = false;
        }
      } else {
        this.validPass = false;
      }
    } else {
      this.validPass = false;
    }
  }



  //-----------------------------------------------------------------------------------------------------------------
  getLoans() {
    this.http.get('http://localhost:3000/getloans', { search: { 'userNumber': this.user.number } })
      .map(res => res.json()).subscribe((data) => {
        if (!data.found) {
          this.loans = [];
        } else {
          this.loans = data.loans;
          for(var i=0;i<this.loans.length;i++){
          
            var tfn = this.loans[i].book.coverArt.split("/");
            var fileNm = tfn[tfn.length - 1];
            this.loans[i].book.coverArt = "http://localhost:3000/pics?image=" + fileNm;
          }
          console.log(this.loans);
        }

      });
  }


  getReserve() {
    this.http.get('http://localhost:3000/getreserves', { search: { 'userNumber': this.user.number } })
      .map(res => res.json()).subscribe((data) => {
        console.log(data);
        if (!data.found) {

          this.reservations = [];
        } else {
          this.reservations = data.reserves;
          for(var i=0;i<this.reservations.length;i++){
          
            var tfn = this.reservations[i].book.coverArt.split("/");
            var fileNm = tfn[tfn.length - 1];
            this.reservations[i].book.coverArt = "http://localhost:3000/pics?image=" + fileNm;
          }
          console.log(this.reservations);
        }


      });
  }

  //-----------------------------------------------------------------------------------------------------------------
  changeNav(name: string) {
    let temp = document.getElementsByClassName('active');
    for (var i = 0; i < temp.length; i++) {
      temp[i].classList.remove("active");
    }
    if (name === "profile") {
      this.nav.profile = true;
      this.nav.changePassword = false;
      this.nav.reservations = false;
      this.nav.loans = false;
      document.getElementById(name).className += " active";
    } else if (name === "changePassword") {
      this.nav.profile = false;
      this.nav.changePassword = true;
      this.nav.reservations = false;
      this.nav.loans = false;
      document.getElementById(name).className += " active";
    } else if (name === "reservations") {
      this.getReserve();
      this.nav.profile = false;
      this.nav.changePassword = false;
      this.nav.reservations = true;
      this.nav.loans = false;
      document.getElementById(name).className += " active";
    } else if (name === "loans") {
      this.getLoans();
      this.nav.profile = false;
      this.nav.changePassword = false;
      this.nav.reservations = false;
      this.nav.loans = true;
      document.getElementById(name).className += " active";
    }
  }

  findSpot(reserve) {
    //console.log(reserve);
    //console.log(reserve._id);
    //console.log(reserve.book.reserve);
    return (reserve.book.reserve.findIndex(el => el == reserve._id) + 1);
  }

  formatDate(rDate) {
    return moment(rDate).format("MMMM D, YYYY");
  }
}
