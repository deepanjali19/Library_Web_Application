import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute} from '@angular/router';
import { Http, Response } from '@angular/http';
import { Location } from '@angular/common';

@Component({
  selector: 'app-barcode',
  templateUrl: './barcode.component.html',
  styleUrls: ['./barcode.component.css']
})
export class BarcodeComponent implements OnInit {
barcode : number;
bookName: string;

  constructor( private activateRoute: ActivatedRoute, private http: Http,private location: Location) {
    this.barcode = this.activateRoute.snapshot.params['barcode'];
    this.http.get("http://localhost:3000/barcode",{ search:{bookNumber: this.barcode}})
    .map(res => res.json()).subscribe((data) => {
      console.log(data);
      this.bookName = data.book.title;
    });
    
   }

  ngOnInit() {
  }
  goBack() {
    this.location.back();

  }
}
