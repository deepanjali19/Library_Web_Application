import { Component, ElementRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {FlashMessagesService} from 'angular2-flash-messages';
@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent {

  userType: string;
  userTypes;
  userName: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  email: string;
  entered: boolean;
  number: string;
  street: string;
  apt: string;
  city: string;
  postalCode: string;
  province: string;


  valid = {
    firstName: true,
    lastName: true,
    email: true,
    phone: true,
    address: true,
    city: true,
    postalCode: true,
    province: true,
    userName: true,
    user: true
  };


  constructor(public http: Http, public el: ElementRef, private flashMessage:FlashMessagesService) {
    this.userType = "client";
    this.userTypes = ["client", "admin"];
    this.entered = false;
  }

  addUser() {
    this.validate(this.firstName,
      this.lastName,
      this.email,
      this.phoneNumber,
      this.street,
      this.city,
      this.province,
      this.postalCode,
      this.userName,
      this.userType,
      this.valid
    );

    if (this.valid.user) {

      let myForm: HTMLFormElement = <HTMLFormElement>document.getElementById('myIForm');
      let formData = new FormData(myForm);

      this.http.post('http://localhost:3000/createuser',
        formData)
        .subscribe(res => {
          var answer = res.json();
          if (answer.success == true) {
            console.log(answer);
            this.entered = true;
            this.userType = answer.userType;
            this.firstName = answer.firstName;
            this.lastName = answer.lastName;
            this.email = answer.email;
            this.phoneNumber = answer.phoneNumber;
            this.number = answer.number;
            this.street = answer.address;
            window.scrollTo(0, 0);

          } else if (answer.success == false) {
            this.flashMessage.show(answer.message, {cssClass: 'alert-danger',timeout: 5000});
            window.scrollTo(0, 0);
            console.log(answer);

          }
        });
    }

  }

  addAnother() {
    this.entered = false;
    this.userType = "client";
    this.firstName = "";
    this.lastName = "";
    this.email = "";
    this.phoneNumber = "";
    this.number = "";
    this.street = ""; 
    this.apt =  "",
    this.city = "",
    this.postalCode =  "",
    this.province = "",
    this.userName = ""

  

  }

  validate(firstName, lastName, email, phone, address, city, province, postalCode, userName, userType, valid) {
    valid.firstName = true;
    valid.lastName = true;
    valid.phone = true;
    valid.email = true;
    valid.user = true;
    valid.address = true;
    valid.city = true;
    valid.postalCode = true;
    valid.province = true;
    valid.userName = true;

    if(userType==="admin"){
      if(!userName){
        valid.userName = false;
      }else if(userName.trim().length < 5){
        valid.userName = false;
      }

    }
    //names
    if (!firstName) {
      valid.firstName = false;
    } else if (firstName.trim().length == 0) {
      valid.firstName = false;
    }

    if (!lastName) {
      valid.lastName = false;
    } else if (lastName.trim().length == 0) {
      valid.lastName = false;
    }
    //email
    if (!email) {
      valid.email = false;
    } else if (email.split('@').length != 2) {
      valid.email = false;
    } else {
      var temp = email.split('@');
      var temp2 = temp[1].split('.');

      if (temp2.length < 2) {
        valid.email = false;
      } else if (temp2[0].length < 1 || temp2[1].length < 1) {
        valid.email = false;
      }
    }

    //phone
    if (!phone) {
      valid.phone = false;
    } else if (phone.length < 10) {
      valid.phone = false;
    } else {
      var temp3 = phone.split('-');

      if (temp3.length != 3) {
        valid.phone = false;
      }

      if ((((temp3[0].trim().length) != 3))) {

        valid.phone = false;

      }
      if (((temp3[1].trim().length) != 3)) {

        valid.phone = false;

      }
      if (((temp3[2].trim().length) != 4)) {

        valid.phone = false;

      }
    }


    //address
    if (!address) {
      valid.address = false;
    } else if (address.trim().length == 0) {
      valid.address = false;
    }
    //city
    if (!city) {
      valid.city = false;
    } else if (city.trim().length == 0) {
      valid.city = false;
    }
    //province
    if (!province) {
      valid.province = false;
    } else if (province.trim().length == 0) {
      valid.province = false;
    }
    //postal code
    var regex = /^[A-Za-z]\d[A-Za-z][ -]?\d[A-Za-z]\d$/;
    var match = regex.exec(postalCode);
    if (!postalCode) {
      valid.postalCode = false;
    } else if (postalCode.trim().length == 0) {
      valid.postalCode = false;
    } else if (!match) {
      valid.postalCode = false;
    }
    //user
    if (valid.firstName &&
      valid.lastName &&
      valid.email &&
      valid.phone &&
      valid.address &&
      valid.city &&
      valid.postalCode &&
      valid.province &&
      valid.userName
    ) {
      valid.user = true;
    } else {
      valid.user = false;
    }

    return valid;
  }






}
