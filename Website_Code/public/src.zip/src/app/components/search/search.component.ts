import { Component, OnInit, Input } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Book } from '../../models/book.model';
import 'rxjs/add/operator/map';
import { DomSanitizer } from '@angular/platform-browser';
import {FlashMessagesService} from 'angular2-flash-messages';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  option;
  query;
  books: Book[];
  basic;
  advanced;
  sortChoice;
  reverse: boolean;
  p: number = 1;
  sortBy = ['title', 'authorFirstName', 'authorLastName', 'isbn', 'publisher', 'year'];
  reservation = {
    'userId': Number,
    'bookId':  Number  }
  constructor(private http: Http, private router: Router, private activatedRoute: ActivatedRoute, private flashMessage:FlashMessagesService, private sanitizer: DomSanitizer) {
    this.sortChoice = "title";
    this.reverse = false;
    this.activatedRoute.queryParams.subscribe(params => {

      if (this.activatedRoute.snapshot.queryParams['searchType'] == 'basic') {
        this.basic = true;
        this.advanced = false;
        if (this.query != params.query || this.option != params.option) {
          this.books = [];
          this.option = params.option.trim();
          this.query = params.query.trim();
        } else {
          this.books = [];
        }

        this.http.get('/search', { search: { searchType: this.activatedRoute.snapshot.queryParams['searchType'], option: this.activatedRoute.snapshot.queryParams['option'], query: this.activatedRoute.snapshot.queryParams['query'] } })
          .map(res => res.json())
          .subscribe(data => {

            this.books = data;

            console.log(data);
          }
          );
      } else if (this.activatedRoute.snapshot.queryParams['searchType'] == 'advanced') {
        this.basic = false;
        this.advanced = true;
        this.books = [];
        this.http.get('/search', { search: { searchType: this.activatedRoute.snapshot.queryParams['searchType'], option: this.activatedRoute.snapshot.queryParams['option'], query: this.activatedRoute.snapshot.queryParams['query'] } })
          .map(res => res.json())
          .subscribe(data => {
            this.books = data;
          }
          );
      }
    });

  }

  ngOnInit() {


  }

  sessionStorageItem(id: string): string {
    return sessionStorage.getItem(id);
  }

  info(id) {
    this.router.navigate(['/info'], { queryParams: { id: id }, skipLocationChange: false });
  }

  modifyBook(id) {
    this.router.navigate(['/info'], { queryParams: { id: id, modify: true }, skipLocationChange: false });
  }

  deleteBook(id) {
    this.router.navigate(['/info'], { queryParams: { id: id, delete: true }, skipLocationChange: false });
  }

  sort(val) {
    if (val) {
      this.reverse = true;
    } else {
      this.reverse = true;
    }
  }

  reserve(id, bookId){
    this.reservation.bookId = bookId;
    this.reservation.userId = id;
    this.http.post('http://localhost:3000/reserve',{userId:id,bookId:bookId}).map(res => res.json()).subscribe(data => {
      if(data.success){
         window.scrollTo(0, 0);
            this.flashMessage.show(data.message, {cssClass: 'alert-success',timeout: 5000});
      }else{
        window.scrollTo(0, 0);
            this.flashMessage.show(data.message, {cssClass: 'alert-danger',timeout: 5000});
      }
      console.log(data.success);
    });
  }
}
