import { Component} from '@angular/core';
import {Router, ActivatedRoute} from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent  {
  userNumber: Number;
  message: string;
  constructor(private http:Http, private router:Router, private activatedRoute: ActivatedRoute) {
    if(activatedRoute.snapshot.params['error']){
      this.message = "Could Not Find User!";
    }else{
      this.message = "";
    }
   }


  findUser(){
    if(this.userNumber){
    this.router.navigate(['/user', this.userNumber] );
    }
  }
}
