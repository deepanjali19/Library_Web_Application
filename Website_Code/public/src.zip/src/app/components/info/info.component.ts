import { Component, OnInit, ElementRef } from '@angular/core';
import { Book } from '../../models/book.model';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { BookValidation } from '../../models/validation.model';
import { Location } from '@angular/common';
import { AddBookService } from '../../services/addbook.service';
import { FlashMessagesService } from 'angular2-flash-messages';
import { FlashMessagesModule } from 'angular2-flash-messages/module/module';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {
  id: string;
  book: Book;
  book2: Book;

  modify: boolean;
  doDelete: boolean;
  valid: BookValidation;
  copyadd: number;


  constructor(private http: Http, private router: Router, private el: ElementRef, private flashMessage: FlashMessagesService, private activatedRoute: ActivatedRoute, private location: Location, private checkBook: AddBookService, private sanitizer: DomSanitizer) {
    this.book = new Book();
    this.copyadd = 0;

    //this.book2 = this.book;



    this.modify = false;
    this.doDelete = false;
    this.valid = new BookValidation();
  }

  ngOnInit() {

    this.activatedRoute.queryParams.subscribe(params => {
      this.id = params.id;
      this.http.get('/info', { search: { id: this.activatedRoute.snapshot.queryParams['id'] } })
        .subscribe(data => {
          var temp = data.json();
          console.log(temp);

          this.book.id = temp.id;
          this.book.title = temp.title;
          this.book.isbn = temp.isbn;
          this.book.year = temp.year;
          this.book.publisher = temp.publisher;
          this.book.description = temp.description;
          this.book.language = temp.language;
          this.book.noCopies = temp.noCopies;
          this.book.authorFirstName = temp.authorFirstName;
          this.book.authorLastName = temp.authorLastName;
          this.book.coverArt = temp.coverArt;
          this.book.reserve = temp.reserve;
          this.book.loan = temp.loan;
          this.book.copies = Object.assign(temp.copies);
          console.log(temp);
          if (params.modify) { this.modify = true, this.book2 = Object.assign({}, this.book); }
          if (params.delete) { this.doDelete = true }
        });

    });
  }
getBarcode(barcode:number){
  this.router.navigate(['/barcode',barcode]);

}
  toggleModify() {
    this.book2 = Object.assign({}, this.book);
    this.modify = (!this.modify);
  }

  toggleDelete() {
    this.doDelete = (!this.doDelete);
  }

  goBack() {
    this.location.back();

  }


  deleteBook(id) {
    this.http.delete('/info', { params: { id: this.book.id } })
      .subscribe(data => {
        var answer = data.json();
        if (answer.success == true) {
          //window.scrollTo(0, 0);
          this.location.back();
          this.flashMessage.show('Book was successfully deleted!', { cssClass: 'alert-success', timeout: 5000 });
        } else if (answer.success == false) {
          window.scrollTo(0, 0);
          this.flashMessage.show('Could not delete book' + answer.error, { cssClass: 'alert-danger', timeout: 5000 });
        }
      });

  }
  
  sessionStorageItem(id: string): string {
    return sessionStorage.getItem(id);
  }

  modifyBook() {


    let inputEl: HTMLInputElement = this.el.nativeElement.querySelector('input[name="photo"]');
    var myForm: HTMLFormElement = <HTMLFormElement>document.getElementById('myIForm');
    let formData = new FormData(myForm);
    console.log(formData);
    this.book2.coverArt = inputEl.files.item(0);
    this.valid = this.checkBook.checkAddBook(this.book2);

    if (this.valid.book == true) {

      var headers = new Headers();
      //headers.append('Content-Type', 'application/json');
      this.http.put('http://localhost:3000/info',
        formData)
        .subscribe(res => {
          var answer = res.json();
          if (answer.success == true) {
            this.book =answer.book;
            this.toggleModify();         
            window.scrollTo(0, 0);
            this.flashMessage.show('Book was successfully updated!!', { cssClass: 'alert-success', timeout: 5000 });
          } else if (answer.success == false) {
            window.scrollTo(0, 0);
            this.flashMessage.show('Could not update book. ' + answer.error, { cssClass: 'alert-danger', timeout: 5000 });
          }
        });
    } else {
      window.scrollTo(0, 0);
    }

  }
  
} 