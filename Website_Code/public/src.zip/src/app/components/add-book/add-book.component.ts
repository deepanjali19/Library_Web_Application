import { Component, ElementRef } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Book } from '../../models/book.model';  
import { BookValidation } from '../../models/validation.model'; 
import {AddBookService} from '../../services/addbook.service';
import {FlashMessagesService} from 'angular2-flash-messages';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent{

  valid: BookValidation;
  book: Book;
  img: any;
  pre: boolean = false;
  url: any;
  
  constructor(public http: Http, private checkBook: AddBookService, private flashMessage:FlashMessagesService, private el: ElementRef ) {
    this.valid = new BookValidation();
    this.book = new Book();
  }

  addBook(){
      
    
    let inputEl: HTMLInputElement = this.el.nativeElement.querySelector('input[name="photo"]');
    var myForm : HTMLFormElement =<HTMLFormElement> document.getElementById('myIForm');
    let formData = new FormData(myForm);
    this.book.coverArt = inputEl.files.item(0);
    this.valid = this.checkBook.checkAddBook(this.book);
    
    console.log(this.book.coverArt);
    if(this.valid.book == true){
      // if(this.book){
        
      var headers = new Headers({});
      this.http.post('http://localhost:3000/addbook',
        formData)
        .subscribe(res => {
          var answer = res.json();
          if(answer.success == true){
            this.book = new Book();
            window.scrollTo(0, 0);
            this.flashMessage.show('Book was added successfully!', {cssClass: 'alert-success',timeout: 5000});
          }else if(answer.success ==false){
            window.scrollTo(0, 0);
            this.flashMessage.show('Book was not added. ' + answer.error, {cssClass: 'alert-danger',timeout: 5000});
          }       
        });  
    }else{
       window.scrollTo(0, 0);
    }
  }

  readUrl(event:any) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
  
      reader.onload = (event:any) => {
        this.url = event.target.result;
      }
  
      reader.readAsDataURL(event.target.files[0]);
    }
  }
}
