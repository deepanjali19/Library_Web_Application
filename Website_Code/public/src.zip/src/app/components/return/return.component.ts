import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, Response } from '@angular/http';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-return',
  templateUrl: './return.component.html',
  styleUrls: ['./return.component.css']
})
export class ReturnComponent implements OnInit {

  bookNumber: string;

  constructor(private http: Http, private flashMessage: FlashMessagesService) {


  }

  ngOnInit() {
  }

  returnbook() {
    this.http.put('http://localhost:3000/return', { bookNumber: this.bookNumber }).map(res => res.json()).subscribe(data => {
      if (data.success) {
        this.bookNumber='';
        window.scrollTo(0, 0);
        this.flashMessage.show(data.message, { cssClass: 'alert-success', timeout: 5000 });
      } else {
        window.scrollTo(0, 0);
        this.flashMessage.show(data.message, { cssClass: 'alert-danger', timeout: 5000 });
      }

    });
  }

}
