import { Component } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import { FlashMessagesService } from 'angular2-flash-messages';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent {
  userNumber: number;
  email: string;
  success: boolean;
  message: string

  constructor(private http: Http, private router: Router, private flashMessage: FlashMessagesService) { 
    this.success = true;
    this.message = "";
  }

  submit(){
    this.http.get('http://localhost:3000/forgot', { search: { number: this.userNumber, email: this.email } }).subscribe(res => {
      
      var answer = res.json();
      this.success = answer.success;                
      this.message = answer.message;
      
      if(this.success){
        this.flashMessage.show(this.message, { cssClass: 'alert-success', timeout: 5000 });
        this.router.navigate(['/']);
      }
      
          

    });
  }


}
