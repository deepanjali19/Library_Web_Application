import { Component } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import {FlashMessagesService} from 'angular2-flash-messages';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent  {

  firstName:string;
  lastName:string;
  email:string;
  phoneNumber:string;
  password: string
  password2:string;
  number: number;
  validPass:boolean;

  constructor(private http: Http, private flashMessage:FlashMessagesService) { this.validPass = true }

  register(){
    if(this.password&&this.password2){
      if(this.password.trim().length>0){
        if(this.password==this.password2){
          this.http.put('http://localhost:3000/register',
          {number: this.number , password: this.password , firstName: this.firstName , lastName: this.lastName , email: this.email , phoneNumber: this.phoneNumber})
          .subscribe(res => {  
            var answer = res.json();
            if(answer.success){
              window.scrollTo(0, 0);
              this.flashMessage.show(answer.message, {cssClass: 'alert-success',timeout: 5000});
            }else{
              window.scrollTo(0, 0);
              this.flashMessage.show(answer.message, {cssClass: 'alert-danger',timeout: 5000});
            }
          });  
        }else{
          this.validPass = false;
        }
      }else{
        this.validPass = false;
      }
    }else{
      this.validPass = false;
    }
  }
  

  togglePass(){
    this.validPass = !this.validPass;
  }

}
