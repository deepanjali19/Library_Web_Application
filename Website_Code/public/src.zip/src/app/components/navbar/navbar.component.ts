import { Component, OnInit } from '@angular/core';
import { Http, Response, Headers, RequestOptions, URLSearchParams } from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  options;
  option: String;
  query: String;
  responseData;

  constructor(public http: Http, private router: Router, private activatedRoute: ActivatedRoute) {
    this.option = "All";
    this.options = ["All","ISBN", "Author", "Title", "Year", "Publisher"]
  }

  ngOnInit() {
  }

  sessionStorageItem(id: string): string {
    return sessionStorage.getItem(id);
  }

  logout() { 
    sessionStorage.clear();
    this.router.navigate(['/']);
  }
  search(query, option) {
    var search = "basic";
    this.router.navigate(['/search'], { queryParams: { searchType: search, option: option, query: query }, skipLocationChange: false });
  }

}

