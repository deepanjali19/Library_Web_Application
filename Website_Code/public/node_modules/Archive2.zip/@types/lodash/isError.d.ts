import { isError } from "./index";
export = isError;
