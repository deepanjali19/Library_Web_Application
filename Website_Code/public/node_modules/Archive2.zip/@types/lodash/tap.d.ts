import { tap } from "./index";
export = tap;
