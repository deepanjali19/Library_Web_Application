import { rangeRight } from "./index";
export = rangeRight;
