import { sortedLastIndex } from "./index";
export = sortedLastIndex;
