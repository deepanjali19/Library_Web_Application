import { isRegExp } from "./index";
export = isRegExp;
