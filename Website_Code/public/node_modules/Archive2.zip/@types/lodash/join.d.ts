import { join } from "./index";
export = join;
