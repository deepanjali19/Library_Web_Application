import { sortBy } from "./index";
export = sortBy;
