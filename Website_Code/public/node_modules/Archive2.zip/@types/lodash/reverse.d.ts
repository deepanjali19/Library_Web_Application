import { reverse } from "./index";
export = reverse;
