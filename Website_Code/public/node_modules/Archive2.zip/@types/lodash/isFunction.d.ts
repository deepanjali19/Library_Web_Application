import { isFunction } from "./index";
export = isFunction;
