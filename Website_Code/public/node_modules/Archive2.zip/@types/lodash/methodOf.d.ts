import { methodOf } from "./index";
export = methodOf;
