import { replace } from "./index";
export = replace;
