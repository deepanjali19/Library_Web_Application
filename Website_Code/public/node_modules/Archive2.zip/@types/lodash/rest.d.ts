import { rest } from "./index";
export = rest;
