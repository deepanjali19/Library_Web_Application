import { snakeCase } from "./index";
export = snakeCase;
