import { toArray } from "./index";
export = toArray;
