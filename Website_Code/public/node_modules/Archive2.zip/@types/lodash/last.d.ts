import { last } from "./index";
export = last;
