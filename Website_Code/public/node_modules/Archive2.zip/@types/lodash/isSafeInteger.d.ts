import { isSafeInteger } from "./index";
export = isSafeInteger;
