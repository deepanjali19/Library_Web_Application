import { updateWith } from "./index";
export = updateWith;
