import { lte } from "./index";
export = lte;
