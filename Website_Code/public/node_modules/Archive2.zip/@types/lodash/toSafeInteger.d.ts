import { toSafeInteger } from "./index";
export = toSafeInteger;
