[![Build Status](https://secure.travis-ci.org/Meettya/whet.extend.png)](http://travis-ci.org/Meettya/whet.extend)

# whet.extend

A sharped version of node.extend as port of jQuery.extend that **actually works** on node.js



## Description

Its drop-in replacement of [node.extend](https://github.com/dreamerslab/node.extend), re-factored and re-written with CoffeeScript

I just need some more CS practice AND its fun :)


## Usage

Checkout the doc from [jQuery](http://api.jquery.com/jQuery.extend/)



