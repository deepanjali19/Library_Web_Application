import { AppiumCommandList } from '../interfaces';
export declare let appium: AppiumCommandList;
