({
    paths: {
        forge: '../js'
    },
    name: 'ui/test.js',
    out: 'ui/test.min.js',
    preserveLicenseComments: false
})
