# Installation
> `npm install --save @types/selenium-webdriver`

# Summary
This package contains type definitions for Selenium WebDriverJS (https://github.com/SeleniumHQ/selenium/tree/master/javascript/node/selenium-webdriver).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/selenium-webdriver/v2

Additional Details
 * Last updated: Wed, 08 Mar 2017 04:58:10 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Bill Armstrong <https://github.com/BillArmstrong>, Yuki Kokubun <https://github.com/Kuniwak>, Craig Nishina <https://github.com/cnishina>.
