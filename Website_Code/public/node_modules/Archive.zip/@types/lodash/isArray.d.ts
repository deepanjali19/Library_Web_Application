import { isArray } from "./index";
export = isArray;
