import { setWith } from "./index";
export = setWith;
