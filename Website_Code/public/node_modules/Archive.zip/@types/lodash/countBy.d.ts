import { countBy } from "./index";
export = countBy;
