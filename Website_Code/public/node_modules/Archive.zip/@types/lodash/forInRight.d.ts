import { forInRight } from "./index";
export = forInRight;
