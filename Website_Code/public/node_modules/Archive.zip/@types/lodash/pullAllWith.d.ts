import { pullAllWith } from "./index";
export = pullAllWith;
