import { trimEnd } from "./index";
export = trimEnd;
