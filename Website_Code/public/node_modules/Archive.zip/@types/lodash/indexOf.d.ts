import { indexOf } from "./index";
export = indexOf;
