import { isNative } from "./index";
export = isNative;
