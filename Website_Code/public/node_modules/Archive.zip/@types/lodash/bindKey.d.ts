import { bindKey } from "./index";
export = bindKey;
