import { update } from "./index";
export = update;
