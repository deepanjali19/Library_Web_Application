import { memoize } from "./index";
export = memoize;
