import { find } from "./index";
export = find;
