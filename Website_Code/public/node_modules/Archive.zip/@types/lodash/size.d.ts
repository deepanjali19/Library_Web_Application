import { size } from "./index";
export = size;
