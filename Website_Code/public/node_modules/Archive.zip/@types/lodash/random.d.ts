import { random } from "./index";
export = random;
