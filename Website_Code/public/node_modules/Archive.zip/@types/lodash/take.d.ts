import { take } from "./index";
export = take;
