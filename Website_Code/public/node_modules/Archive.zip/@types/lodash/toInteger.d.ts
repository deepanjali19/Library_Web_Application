import { toInteger } from "./index";
export = toInteger;
