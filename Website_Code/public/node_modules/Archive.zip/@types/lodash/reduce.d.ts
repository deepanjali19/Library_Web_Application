import { reduce } from "./index";
export = reduce;
