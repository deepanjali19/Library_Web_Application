import { map } from "./index";
export = map;
